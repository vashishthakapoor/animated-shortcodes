<?php
/*
Plugin Name: Animated Shortcodes for WordPress
Plugin URI: http://vashishthakapoor.com/
Description: Add effects and animations in the shortcodes plugin using hover.css and animate.css
Author: Vashishtha Kapoor
Version: 1.4.2
Author URI: http://vashishthakapoor.com/
*/

function mts_wpshortcodes_scripts() {
            
           
    wp_register_style('tipsy', plugins_url('css/tipsy.css', __FILE__));
    wp_enqueue_style( 'tipsy' );

    wp_register_style('mts_wpshortcodes', plugins_url('css/wp-shortcode.css', __FILE__));
    wp_enqueue_style('mts_wpshortcodes');
    
    wp_register_style('new', plugins_url('css/animate.css', __FILE__));
    wp_enqueue_style('new');
    
    wp_register_style('hover', plugins_url('css/hover.css', __FILE__));
    wp_enqueue_style('hover');
    
    wp_register_script('tipsy', plugins_url('js/jquery.tipsy.js', __FILE__), array('jquery'));
    wp_enqueue_script( 'tipsy' );
    wp_register_script('mts_wpshortcodes', plugins_url('js/wp-shortcode.js', __FILE__), array('jquery'));
    wp_enqueue_script('mts_wpshortcodes');
}
add_action('wp_enqueue_scripts', 'mts_wpshortcodes_scripts', 99);

function mts_wpshortcodes_load_textdomain() {
  load_plugin_textdomain( 'wp-shortcode', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
add_action( 'plugins_loaded', 'mts_wpshortcodes_load_textdomain' );

// hide built-in shortcodes button for MTS themes
add_action('admin_head', 'mts_wpshortcodes_theme_compatibility');

function mts_wpshortcodes_theme_compatibility() {
  echo '<style type="text/css">#content_mnmpanel {display: none;}</style>';
}

include('tinymce/tinymce.php');

// override theme shortcodes
add_action( 'after_setup_theme', 'mts_wpshortcodes_add' );

function mts_wpshortcodes_add() {
    remove_shortcode('button-brown'); add_shortcode('button-brown', 'mts_button_brown');
    remove_shortcode('button-blue'); add_shortcode('button-blue', 'mts_button_blue');
    remove_shortcode('button-green'); add_shortcode('button-green', 'mts_button_green');
    remove_shortcode('button-red'); add_shortcode('button-red', 'mts_button_red');
    remove_shortcode('button-white'); add_shortcode('button-white', 'mts_button_white');
    remove_shortcode('button-yellow'); add_shortcode('button-yellow', 'mts_button_yellow');
    remove_shortcode('alert-note'); add_shortcode('alert-note', 'mts_alert_note');
    remove_shortcode('alert-announce'); add_shortcode('alert-announce', 'mts_alert_announce');
    remove_shortcode('alert-success'); add_shortcode('alert-success', 'mts_alert_success');
    remove_shortcode('alert-warning'); add_shortcode('alert-warning', 'mts_alert_warning');
    remove_shortcode('one_third'); add_shortcode('one_third', 'mts_one_third');
    remove_shortcode('one_third_last'); add_shortcode('one_third_last', 'mts_one_third_last');
    remove_shortcode('two_third'); add_shortcode('two_third', 'mts_two_third');
    remove_shortcode('two_third_last'); add_shortcode('two_third_last', 'mts_two_third_last');
    remove_shortcode('one_half'); add_shortcode('one_half', 'mts_one_half');
    remove_shortcode('one_half_last'); add_shortcode('one_half_last', 'mts_one_half_last');
    remove_shortcode('vimeo'); add_shortcode('vimeo', 'mts_vimeo_video');
    remove_shortcode('googlemap'); add_shortcode('googlemap', 'mts_googleMaps');
    remove_shortcode('tabs'); add_shortcode('tabs', 'mts_tabs');
    remove_shortcode('toggle'); add_shortcode('toggle', 'mts_toggle');
    remove_shortcode('divider'); add_shortcode('divider', 'mts_divider');
    remove_shortcode('divider_top'); add_shortcode('divider_top', 'mts_divider_top');
    remove_shortcode('clear'); add_shortcode('clear', 'mts_clear');
    add_shortcode('tooltip', 'mts_tooltip');
    remove_shortcode('mycode'); add_shortcode('mycode', 'mts_mycode');
}


/*-----------------------------------------------------------------------------------*/
/*	Buttons Shortcodes
/*-----------------------------------------------------------------------------------*/

function mts_button_brown( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_brown " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

function mts_button_blue( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_blue " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

function mts_button_green( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_green " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

function mts_button_red( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_red " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

function mts_button_white( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_white " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

function mts_button_yellow( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'url'     	 => '#',
        'animation'     => 'hvr',
		'target'     => '_self',
		'position'   => 'left'
    ), $atts));
	$out = "<a href=\"" .$url. "\" target=\"" .$target. "\" class=\"buttons btn_yellow " .$position. " " .$animation. " \"><span class=\"left\">".do_shortcode($content)."</span></a>";
    if ($position == 'center') {
        $out = '<div class="button-center">'.$out.'</div>';
    }
    return $out;
}

/*-----------------------------------------------------------------------------------*/
/*	Alert Shortcodes
/*-----------------------------------------------------------------------------------*/

function mts_alert_note( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'style'    	 => 'note' ,
        'effect'    	 => 'hvr'
    ), $atts));
	$out = "<div class=\"message_box note " .$effect. " \"><p>".do_shortcode($content)."</p></div>";
    return $out;
}

function mts_alert_announce( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'style'    	 => 'announce' ,
        'effect'    	 => 'hvr'
    ), $atts));
	$out = "<div class=\"message_box announce " .$effect. " \"><p>".do_shortcode($content)."</p></div>";
    return $out;
}

function mts_alert_success( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'style'    	 => 'success' ,
        'effect'    	 => 'hvr'
    ), $atts));
	$out = "<div class=\"message_box success " .$effect. " \"><p>".do_shortcode($content)."</p></div>";
    return $out;
}

function mts_alert_warning( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'style'    	 => 'warning' ,
        'effect'    	 => 'hvr'
    ), $atts));
	$out = "<div class=\"message_box warning " .$effect. " \"><p>".do_shortcode($content)."</p></div>";
    return $out;
}

/*-----------------------------------------------------------------------------------*/
/*	Column Shortcodes
/*-----------------------------------------------------------------------------------*/

function mts_one_third( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"one_third " .$effect. " \">".do_shortcode($content)."</div>";
    return $out;
}

function mts_one_third_last( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"one_third column-last " .$effect. " \">".do_shortcode($content)."</div><div class=\"clear\"></div>";
    return $out;
}

function mts_two_third( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"two_third " .$effect. " \">".do_shortcode($content)."</div>";
    return $out;
}

function mts_two_third_last( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"two_third column-last " .$effect. " \">".do_shortcode($content)."</div><div class=\"clear\"></div>";
    return $out;
}

function mts_one_half( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"one_half " .$effect. " \">".do_shortcode($content)."</div>";
    return $out;
}

function mts_one_half_last( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'effect'    	 => 'hvr'
    ), $atts));
    $out = "<div class=\"one_half column-last " .$effect. " \">".do_shortcode($content)."</div><div class=\"clear\"></div>";
    return $out;
}



/*-----------------------------------------------------------------------------------*/
/*	Video Shortcodes
/*-----------------------------------------------------------------------------------*/
function mts_youtube_video( $atts, $content = null ) {  
    extract(shortcode_atts( array(  
        'id' => '',  
        'width' => '600',  
        'height' => '340',
		    'position'   => 'left'
    ), $atts));  
    $out = "<div class=\"youtube-video " .$position . "\"><iframe width=\"" .$width . "\" height=\"" .$height ."\" src=\"//www.youtube.com/embed/" . $id . "?rel=0\" frameborder=\"0\" allowfullscreen></iframe></div>";
	return $out;
}  

function mts_vimeo_video( $atts, $content = null ) {  
    extract(shortcode_atts( array(  
        'id' => '',  
        'width' => '600',  
        'height' => '340',
		'position'   => 'left'
    ), $atts));  
    $out = "<div class=\"vimeo-video " .$position . "\"><iframe width=\"" .$width . "\" height=\"" .$height ."\" src=\"//player.vimeo.com/video/" . $id . "?title=0&amp;byline=0&amp;portrait=0\" frameborder=\"0\" allowfullscreen></iframe></div>";
	return $out;
}  

/*-----------------------------------------------------------------------------------*/
/*	GoogleMaps Shortcode
/*-----------------------------------------------------------------------------------*/
function mts_googleMaps($atts, $content = null) {
   extract(shortcode_atts(array(
      'width' => '640',
      'height' => '480',
      'address' => '',
      'src' => '', // for backwards compatibility
	  'position' => 'left'
   ), $atts));
   if (!empty($src)) {
     $out = "<div class=\"googlemaps " .$position . "\"><iframe width=\"".$width."\" height=\"".$height."\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"".$src."&output=embed\"></iframe></div>";
   } else {
     $out = "<div class=\"googlemaps " .$position . "\"><iframe width=\"".$width."\" height=\"".$height."\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"//maps.google.com/maps?q=".urlencode($address)."&output=embed\"></iframe></div>";
   }
   return $out;
}

/*-----------------------------------------------------------------------------------*/
/*	Tabs
/*-----------------------------------------------------------------------------------*/
function mts_tabs( $atts, $content = null ) {
	
	if (!preg_match_all("/(.?)\[(tab)\b(.*?)(?:(\/))?\](?:(.+?)\[\/tab\])?(.?)/s", $content, $matches)) {
		return do_shortcode($content);
	} else {
		for($i = 0; $i < count($matches[0]); $i++) {
			$matches[3][$i] = shortcode_parse_atts($matches[3][$i]);
			$tabid[$i] = 'tab-'.$i.'-'.strtolower(sanitize_title($matches[3][$i]['title']));
		}
		$tabnav = '<ul class="wps_tabs">';
		
		for($i = 0; $i < count($matches[0]); $i++) {
			$tabnav .= '<li><a href="#" data-tab="'.$tabid[$i].'">' . $matches[3][$i]['title'] . '</a></li>';
		}
		$tabnav .= '</ul>';
		
		$tabcontent = '<div class="tab_container">';
		for($i = 0; $i < count($matches[0]); $i++) {
			$tabcontent .= '<div id="'.$tabid[$i].'" class="tab_content clearfix">' . do_shortcode(trim($matches[5][$i])) . '</div>';
		}
		$tabcontent .= '</div>';

		return '<div class="tab_widget wp_shortcodes_tabs">' . $tabnav . $tabcontent . '</div><div class="clear"></div>';
	}
    
}
add_filter( 'no_texturize_shortcodes', 'no_texturize_tabs' );
function no_texturize_tabs($shortcodes){
    $shortcodes[] = 'tabs';
    return $shortcodes;
}

/*--------------------------------------------------------
    Toggles
--------------------------------------------------------*/

function mts_toggle( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'title' => __('Toggle Title', 'wp-shortcode')
	), $atts));
    
	return '<div class="toggle clearfix wp_shortcodes_toggle"><div class="wps_togglet"><span>' . $title . '</span></div><div class="togglec clearfix">' . do_shortcode(trim($content)) . '</div></div><div class="clear"></div>';
}

/*-----------------------------------------------------------------------------------*/
/*	Divider 
/*-----------------------------------------------------------------------------------*/
// simple divider
function mts_divider( $atts ) {
    return '<div class="divider"></div>';
}

// Divider with an anchor link to top of page.
function mts_divider_top( $atts ) {
    return '<div class="top-of-page"><a href="#top">'.__('Back to Top', 'wp-shortcode').'</a></div>';
}

// Used to clear an element of its neighbors, no floating elements are allowed on the left or the right side.
function mts_clear( $atts ) {
    return '<div class="clear"></div>';
}


/*-----------------------------------------------------------------------------------*/
/*  Tooltip 
/*-----------------------------------------------------------------------------------*/

function mts_tooltip( $atts, $content ) {
    $atts = shortcode_atts(array(
      'content' => '',
      'gravity' => 'n',
      'fade' => '0'
    ), $atts);
    return '<span class="wp_shortcodes_tooltip" title="'.esc_attr( $atts['content'] ).'" data-gravity="'.esc_attr( $atts['gravity'] ).'" data-fade="'.esc_attr( $atts['fade'] ).'">'.$content.'</span>';
}


/*-----------------------------------------------------------------------------------*/
/*  MyCode
/*-----------------------------------------------------------------------------------*/

function mts_mycode( $atts, $content ) {
    $atts = shortcode_atts(array(
      'content' => '',
      'gravity' => 'n',
      'fade' => '0'
    ), $atts);
    return '<span class="wp_shortcodes_tooltip" title="'.esc_attr( $atts['content'] ).'" data-gravity="'.esc_attr( $atts['gravity'] ).'" data-fade="'.esc_attr( $atts['fade'] ).'">'.$content.'</span>';
}
?>